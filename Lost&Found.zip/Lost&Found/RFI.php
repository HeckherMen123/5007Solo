<?php
require_once('./RFIfun.php');

?>


<!DOCTYPE html>
<html lang="utf=8">

<html>
<head>
<title>Report Form for found items</title>
<link rel="stylesheet" href="style.css">


</head>
<body>
<div class="banner">
<section>
<h1 align ="center"><font size="12"><u>Report Found Items</u></h1>
</section>
<h1 align ="center"><a href="Inti Lost&Found.html"><img src ="images/main.jpg" width="200" height="50"></a><a href="RLI.html"><img src ="images/lost.jpg" width="200" height="50"></a><a href="Found.php"><img src ="images/found.jpg" width="200" height="50"></a><a href="Report.html"><img src ="images/report.jpg" width="200" height="50"></a><a href="Enquiry.html"><img src ="images/enquiry.jpg" width="200" height="50"></a> </h1>  

<div class="detail">
<p>Enter your name, phone number and upload the image of the found items:</p>
</div>



<form action="Found.php" method="post" enctype="multipart/form-data">
<div class="form">
<?php inputFields("Name","name","","text") ?>
<?php inputFields("phone number","phone","","text") ?>
<?php inputFields("","file","","file") ?>
<input type="submit" class="form-control submit" value="Submit" name="submit" >
</form>
<div class="form">

</div>
</body>
</html>