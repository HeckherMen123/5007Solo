<?php

include ('./lostdata.php');
 
 if (isset($_GET['id'])){
$id=$_GET['id'];
$delete=mysqli_query($con,"DELETE FROM `lost` WHERE `id`='$id'");
	
}

if (isset($_POST['submit'])){
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$idesc=$_POST['idesc'];
	$timelost=$_POST['timelost'];
	$placelost=$_POST['placelost'];
	//echo $name;
	//echo $phone;
	//echo $email;
	//echo $idesc;
	//echo $timelost;
	//echo $placelost;
	
	$sql="insert into `lost` (name, phone, email, idesc, timelost, placelost) values('$name','$phone','$email','$idesc','$timelost','$placelost')";
        $result=mysqli_query($con,$sql);
if($result){
    echo "Data inserted";
}else{
    die(mysqli_error($con));
}
			
}
?>

<!DOCTYPE html>
<html lang="utf=8">


<html>
<head>
<title>Lost Items Page</title>
<link rel="stylesheet" href="style.css">
<style>

</style>

</head>

<body>
<div class="banner">
<section>
<h1 align ="center"><font size="12"><u>LOST ITEMS</u></h1>
</section>
<h1 align ="center"><a href="Inti Lost&Found.html"><img src ="images/main.jpg" width="200" height="50"></a><a href="Lost.php"><img src ="images/lost.jpg" width="200" height="50"></a><a href="Found.php"><img src ="images/found.jpg" width="200" height="50"></a><a href="Report.html"><img src ="images/report.jpg" width="200" height="50"></a><a href="Enquiry.html"><img src ="images/enquiry.jpg" width="200" height="50"></a> </h1>  

<div class="lost">
<p align="center">Items Lost:</p>

</div>

<table>
  <thead>
    <tr>
      <th>No.</th>
      <th>Name</th>
      <th>Phone Number</th>
      <th>Email</th>
	  <th>Lost Item Desc.</th>
	  <th>Time Of Incident</th>
	  <th>Place Of Incident</th>
	  <th>Delete Lost Items</th>
    </tr>
  </thead>
  <tbody>
  <?php
$sql="Select *from `lost`";
  $result=mysqli_query($con,$sql);
  while($row=mysqli_fetch_assoc($result)){
    $id=$row['id'];
    $name=$row['name'];
    $phone=$row['phone'];
    $email=$row['email'];
	$idesc=$row['idesc'];
	$timelost=$row['timelost'];
	$placelost=$row['placelost'];
echo "<tr>
      <td>".$id."</td>
      <td>".$name."</td>
      <td>".$phone."</td>
	  <td>".$email."</td>
	  <td>".$idesc."</td>
	  <td>".$timelost."</td>
	  <td>".$placelost."</td>
      <td> 
         <a href='Lost.php?id=".$id."' class='btn'><img src ='images/X.jpg' width='40' height='40'></a>
      </td>
    </tr>";
}
?>
 </tbody>
</table>
</div>
</body>
</html>