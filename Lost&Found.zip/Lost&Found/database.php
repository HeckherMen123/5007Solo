<?php

$con= mysqli_connect("localhost","root","","found");

if(!$con){
	die(mysql_error($con));
}

?>