<?php

$con= mysqli_connect("localhost","root","","lost");

if(!$con){
	die(mysql_error($con));
}

?>