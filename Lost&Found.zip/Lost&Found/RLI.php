<?php
require_once('./RLIdata.php');

?>
<!DOCTYPE html>
<html lang="utf=8">


<html>
<head>
<title>Lost Item Report Page</title>
<link rel="stylesheet" href="Mainstyle.css">


</head>



<body>
<div class="banner">
<section>
<h1 align ="center"><font size="12"><u>Lost Item Report Page</u></h1>
</section>
<h1 align ="center"><a href="Inti Lost&Found.html"><img src ="images/main.jpg" width="200" height="50"></a><a href="Lost.php"><img src ="images/lost.jpg" width="200" height="50"></a><a href="Found.php"><img src ="images/found.jpg" width="200" height="50"></a><a href="report.html"><img src ="images/report.jpg" width="200" height="50"></a><a href="Enquiry.html"><img src ="images/enquiry.jpg" width="200" height="50"></a> </h1>  


<form action="Lost.php" method="post" enctype="multipart/form-data">
<div class="form">

    <?php inputFields("Name","name","","text") ?>
	
    <?php inputFields("Phone","phone","","text") ?>
	
    <?php inputFields("Email","email","","text") ?>

    <?php inputFields("Lost Item Description","idesc","","text") ?>
	
    <?php inputFields("Time of Lost Item","timelost","","text") ?>
	
    <?php inputFields("Place of Lost Item","placelost","","text") ?>

    <input type="submit" class="form-control submit" value="Submit" name="submit" >

  </form>

</div>


</body>
</html>