<?php

include ('./database.php');
 
 if (isset($_GET['id'])){
$id=$_GET['id'];
$delete=mysqli_query($con,"DELETE FROM `found` WHERE `id`='$id'");
	
}

if (isset($_POST['submit'])){
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$image=$_FILES['file'];
	//echo $name;
	//echo $phone;
	//print_r($image);
	
	$imagefilename=$image['name'];
	//print_r($imagefilename);

	$imagefileerror=['error'];
	//print_r($imagefileerror);

	$imagefiletemp=$image['tmp_name'];
	//print_r($imagefiletemp);

	$filename_separate=explode('.',$imagefilename);
	//print_r($filename_separate);

	$file_extension=strtolower(end($filename_separate));
	//print_r($file_extension);
	
	$extension=array('jpeg','jpg','png');
	if(in_array($file_extension, $extension)){
		$upload_image='images/'.$imagefilename;
		move_uploaded_file($imagefiletemp,$upload_image);
		$sql="insert into `found` (name, phone, image) values('$name','$phone','$upload_image')";
		$result=mysqli_query($con,$sql);
if($result){
	echo "Data inserted";
}else{
	die(mysqli_error($con));
}

	
			
}	
}
?>

<!DOCTYPE html>
<html lang="utf=8">


<html>
<head>
<title>Found Page</title>
<link rel="stylesheet" href="style.css">
<style>

</style>

</head>

<body>
<div class="banner">
<section>
<h1 align ="center"><font size="12"><u>FOUND</u></h1>
</section>
<h1 align ="center"><a href="Inti Lost&Found.html"><img src ="images/main.jpg" width="200" height="50"></a><a href="Lost.php"><img src ="images/lost.jpg" width="200" height="50"></a><a href="Found.php"><img src ="images/found.jpg" width="200" height="50"></a><a href="Report.html"><img src ="images/report.jpg" width="200" height="50"></a><a href="Enquiry.html"><img src ="images/enquiry.jpg" width="200" height="50"></a> </h1>  

<div class="found">
<p align="center">Items Found:</p>

</div>

<table>
  <thead>
    <tr>
      <th>No.</th>
      <th>Name</th>
      <th>Phone Number</th>
      <th>Found Items</th>
	  <th>Delete Found Items</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $sql="Select *from `found`";
  $result=mysqli_query($con,$sql);
  while($row=mysqli_fetch_assoc($result)){
	$id=$row['id'];
    $name=$row['name'];
	$phone=$row['phone'];
    $image=$row['image'];
echo "<tr>
      <td>".$id."</td>
      <td>".$name."</td>
      <td>".$phone."</td>
      <td><img src=".$image." width='170' height='120'></td>
	  <td> 
	     <a href='Found.php?id=".$id."' class='btn'><img src ='images/X.jpg' width='40' height='40'></a>
	  </td>
    </tr>";	

}
  
  
  
  
  ?>
 </tbody>
</table>
</div>
</body>
</html>